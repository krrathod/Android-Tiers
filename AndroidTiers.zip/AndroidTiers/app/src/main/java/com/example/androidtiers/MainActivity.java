package com.example.androidtiers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.androidtiers.firstTiers.firstTiersMainActivity;
import com.example.androidtiers.thirdTiers.thirdMainActivity;

public class MainActivity extends AppCompatActivity {
    Button firstTier, thirdTier;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstTier = findViewById(R.id.button);
        thirdTier = findViewById(R.id.button2);

        firstTier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),firstTiersMainActivity.class);
                startActivity(intent);
            }
        });

        thirdTier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), thirdMainActivity.class);
                startActivity(intent);
            }
        });

    }
}